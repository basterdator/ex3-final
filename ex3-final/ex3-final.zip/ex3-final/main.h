#ifndef __MAIN_H__
#define __MAIN_H__


// Includes --------------------------------------------------------------------
#include <windows.h>

// Constants  ------------------------------------------------------------------


HANDLE laundry_room;
HANDLE laundry_full;
HANDLE laundry_empty;
HANDLE write_to_file;


#endif // __MAIN_H__
